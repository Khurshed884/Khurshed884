import React from "react";

const Navbar = () => {
  return (
    <nav style={{ backgroundColor: "#d32f2f", padding: "10px" }}>
      <h2 style={{ color: "#fff", margin: "033" }}>KababJees Fried Chicken</h2>
    </nav>
  );
};

export default Navbar;
