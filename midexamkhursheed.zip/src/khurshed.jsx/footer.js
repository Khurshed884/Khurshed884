import React from "react";

const Footer = () => {
  return (
    <footer style={{ backgroundColor: "#d32f2f", color: "#fff", padding: "15px", textAlign: "center" }}>
      <p>© 2024 KababJees Fried Chicken. .</p>

    </footer>
  );
};

export default Footer;
