import React from 'react';
//import Greeting from './khurshed.jsx/Greeting';
//import Messages from './khurshed.jsx/SpecialityMenu';
import Statistics from './khurshed.jsx/footer';
import Navbar from './khurshed.jsx/Navbar';
import LandingPage from './khurshed.jsx/LandingPage';
import SpecialityMenu from './khurshed.jsx/SpecialityMenu';
import Footer from './khurshed.jsx/footer';

const App = () => {
  const items = [
    {
      name: "Spicy Chicken Wings",
      description: "Our signature spicy wings",
      price: "Rs. 500",
      image: "https://images.deliveryhero.io/image/fd-pk/Products/49411247.jpg?width=%s",
    },
    {
      name: "Classic Fried Chicken",
      description: "Traditional recipe",
      price: "Rs. 350",
      image: "https://images.deliveryhero.io/image/fd-pk/Products/26754778.jpg?width=%s",
    },
    {
      name: "Chicken Burger Combo",
      description: "Burger with fries and drink",
      price: "Rs. 650",
      image: "https://images.deliveryhero.io/image/fd-pk/Products/58219340.jpg?width=%s",
    },
  ];

  return (
    <div>
      <Navbar />
      <LandingPage />
      <div style={{ marginTop: "40px", backgroundColor: "#f9f9f9", padding: "20px 0" }}>
        <h2 style={{ textAlign: "center", color: "#d32f2f", marginBottom: "20px" }}>
          Our Speciality Menu
        </h2>
        <SpecialityMenu items={items} />
      </div>
      <Footer />
    </div>
  );
};

export default App;